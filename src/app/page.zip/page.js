"use client"
 import {Component} from "react";

class Home extends Component{

  constructor() {
    super();
    this.state ={
      count: 0
    }
  }

  componentDidMount() {
    console.log("Me renderizo")
  }
componentDidUpdate(){
  console.log("Me actualizo")

}
aumentar = () => {
  this.setState ({
    count: this.state.count +1
  })
}

restar = () => {
  this.setState ({
    count: this.state.count -1
  })
}

  render() {
    return(
      <div>
        Hola mundo x{this.state.count}.!
        <button onClick={this.aumentar}>AUMENTAR</button>
        <button onClick={this.restar}>RESTAR</button>
      </div>
    )
  }
}
export default Home;